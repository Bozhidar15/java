package bg.sofia.uni.fmi.mjt.news.exception.errors;

public class UnauthorizedException extends Exception {
    public UnauthorizedException(String message) {
        super(message);
    }

}
