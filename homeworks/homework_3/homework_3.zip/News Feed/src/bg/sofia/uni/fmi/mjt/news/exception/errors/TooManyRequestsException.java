package bg.sofia.uni.fmi.mjt.news.exception.errors;

public class TooManyRequestsException extends Exception {
    public TooManyRequestsException(String message) {
        super(message);
    }

}
